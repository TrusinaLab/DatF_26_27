# Submission types:
# ON_TIME = 1
# LATE = 2
# MISSING = 3
# EARLY = 4


def calculate_average_grade(grades):
    """Calculate the average grade from a list of student grades."""
    if not grades:
        return 0.0
    return sum(grades) / len(grades)


def get_score_from_submission_type(submission_type):
    if submission_type == 1:
        return 1.0
    elif submission_type == 2:
        return 0.8
    elif submission_type == 3:
        return 0.0
    elif submission_type == 4:
        return 1.5
    else:
        return 0.0


def check_if_name_is_valid(name):
    """Check if the student's name is valid (non-empty and contains only letters)"""
    return len(name) > 0 and name.isalpha()


def process_student(student_name, grades, submission_type):
    """Process a student's submission to calculate score, class, and description."""
    average_score = calculate_average_grade(grades)
    submission_score = get_score_from_submission_type(submission_type)
    grade_class = int(average_score // 10)  # Classify into 0-9 based on score range
    name_valid = check_if_name_is_valid(student_name)

    return average_score, grade_class, submission_score, name_valid, student_name


def is_top_student(
    average_score, grade_class, submission_score, name_valid, student_name
):
    """Determine and return the top student based on criteria."""
    if name_valid and grade_class >= 8 and average_score * submission_score >= 70:
        return True
    return False
