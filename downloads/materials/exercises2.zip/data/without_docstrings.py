from math import isfinite, sqrt


def summarize_measurements(
    readings: list[float],
    background: float = 0.0,
    scale: float = 1.0,
    max_abs_value: float | None = None,
) -> tuple[float, float, int]:

    if not readings:
        raise ValueError("No measurements provided")

    if not isfinite(scale) or scale <= 0:
        raise ValueError("Scale must be positive and finite")

    if not isfinite(background):
        raise ValueError("Background must be finite")

    if max_abs_value is not None and max_abs_value < 0:
        raise ValueError("Maximum value cannot be negative")

    processed = []

    for reading in readings:
        if not isfinite(reading):
            continue

        value = (reading - background) * scale

        if max_abs_value is not None and abs(value) > max_abs_value:
            continue

        processed.append(value)

    if not processed:
        raise ValueError("No valid measurements remaining")

    mean = sum(processed) / len(processed)

    variance = sum((value - mean) ** 2 for value in processed) / len(processed)

    return mean, sqrt(variance), len(processed)


def detect_signal_events(
    signal: list[float],
    threshold: float,
    min_hits: int = 2,
    max_gap: int = 0,
) -> list[tuple[int, int, float]]:

    if min_hits < 1:
        raise ValueError("min_hits must be positive")

    if max_gap < 0:
        raise ValueError("max_gap cannot be negative")

    events = []
    start = None
    last_hit = -1
    hits = 0
    peak = float("-inf")

    for i in range(len(signal)):

        if signal[i] > threshold:

            if start is None:
                start = i
                hits = 0
                peak = signal[i]

            hits += 1
            peak = max(peak, signal[i])
            last_hit = i

        elif start is not None and i - last_hit > max_gap:

                if hits >= min_hits:
                    events.append((start, last_hit + 1, peak))

                start = None
                hits = 0
                peak = float("-inf")

    if start is not None and hits >= min_hits:
        events.append((start, last_hit + 1, peak))

    return events
